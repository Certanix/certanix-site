# GENERATED FILE. DO NOT EDIT.
#
# Vendored from certanix/vault_verify.py by tools/vendor_verify_core.py, with ONE
# rewrite: its import of certanix.verify_core reads from ._core. Edit the SOURCE.

"""Offline verification of Vault evidence records (RFC 4998) and their RFC 3161 tokens.

A Vault evidence record shows that some bytes (an artefact and its manifest) existed
unchanged at the time a time-stamping authority (TSA) stated. It is checked here with
nothing but the bytes, the record and the TSA trust anchors the verifier chooses: no
network, no platform code. This module is vendored into ``certanix-verify`` (as
``_vault.py``) by ``tools/vendor_verify_core.py``, with one recorded import rewrite.

**What it checks, in order, stopping at the first failure** (the classes are
``verify_core.VerificationStatus`` 10 to 13; Vault plan C.18):

1. The record parses as an RFC 4998 ``EvidenceRecord``. Otherwise ``MALFORMED_INPUT``.
2. Every supplied data object's hash is in the first list of the reduced hash tree, and
   the tree recomputes to the hash the token stamped. Otherwise ``EVIDENCE_MISMATCH``.
3. The token is a valid RFC 3161 token: its CMS signature verifies over its signed
   attributes, the message digest matches the token content, and the signing-certificate
   attribute names the signing certificate. Otherwise ``TIMESTAMP_INVALID``.
4. The signing certificate is a time-stamping certificate that chains to a supplied trust
   anchor, every certificate in the path valid when the token was issued. Otherwise
   ``TSA_UNTRUSTED``.
5. At the verification time, the time-stamping certificate has not expired. Otherwise
   ``TSA_EXPIRED``: the record needed renewal before then (Vault WP3).

**What it does not check, stated so it is not over-read:** revocation (no CRL or OCSP:
the check is offline by design), and the TSA's policy. A passing record shows that the
bytes are unchanged since the stated time, as attested by whoever holds the trust anchor
the verifier supplied. It says nothing about whether the content is true.

**Hash tree** (RFC 4998 section 4.2): the hash of a node is the hash of its children's
hash values, sorted in binary ascending order and concatenated. A data object group (an
artefact and its manifest) is one leaf whose children are the group's hashes. Each
artefact's record carries its own reduced hash tree, so it verifies alone, without the
other members of its batch.
"""

from __future__ import annotations

import datetime as dt
import hashlib
from typing import Iterable

from asn1crypto import algos, cms, core, tsp
from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, padding, rsa
from cryptography.hazmat.primitives.serialization import Encoding

from ._core import VerificationResult, VerificationStatus

VAULT_VERIFY_VERSION = "1.0.0"

_DER = Encoding.DER

#: Hash algorithms a record may use, by asn1crypto name. SHA-256 is where records start;
#: the others are successors a renewal can move to (Vault plan C.18 condition 3).
HASHES = {
    "sha256": hashlib.sha256,
    "sha384": hashlib.sha384,
    "sha512": hashlib.sha512,
    "sha3_256": hashlib.sha3_256,
    "sha3_512": hashlib.sha3_512,
}

_CRYPTO_HASHES = {
    "sha256": hashes.SHA256,
    "sha384": hashes.SHA384,
    "sha512": hashes.SHA512,
    "sha3_256": hashes.SHA3_256,
    "sha3_512": hashes.SHA3_512,
}


# --------------------------------------------------------------------------- #
# RFC 4998 structures (ASN.1 module ERS, IMPLICIT TAGS)
# --------------------------------------------------------------------------- #


class Attribute(core.Sequence):
    """RFC 4998 uses the CMS ``Attribute`` (RFC 5652): a type and a SET OF values."""

    _fields = [
        ("type", core.ObjectIdentifier),
        ("values", core.SetOf, {"spec": core.Any}),
    ]


class Attributes(core.SetOf):
    _child_spec = Attribute


#: The attribute every archive timestamp the Vault writes carries, naming the hash-tree
#: convention it was built with, so a future verifier knows which it is reading (C.24).
#: The type is an OID under the UUID arc (2.25), which needs no registration.
CONVENTION_OID = "2.25.68057550963730349834487419971878921163"  # uuid5(URL, "certanix-ers-tree-convention")
CONVENTION = (
    "certanix-ers-tree/2: RFC 4998 4.2 nodes sorted and hashed, a single-value node is "
    "its value; 5.3 renewal leaf H(h(d) + ha), data hash first; as Bouncy Castle "
    "org.bouncycastle.tsp.ers 1.86"
)
KNOWN_CONVENTIONS = (CONVENTION,)


class PartialHashtree(core.SequenceOf):
    _child_spec = core.OctetString


class PartialHashtrees(core.SequenceOf):
    _child_spec = PartialHashtree


class ArchiveTimeStamp(core.Sequence):
    _fields = [
        ("digest_algorithm", algos.DigestAlgorithm, {"implicit": 0, "optional": True}),
        ("attributes", Attributes, {"implicit": 1, "optional": True}),
        ("reduced_hashtree", PartialHashtrees, {"implicit": 2, "optional": True}),
        ("time_stamp", cms.ContentInfo),
    ]


class ArchiveTimeStampChain(core.SequenceOf):
    _child_spec = ArchiveTimeStamp


class ArchiveTimeStampSequence(core.SequenceOf):
    _child_spec = ArchiveTimeStampChain


class DigestAlgorithms(core.SequenceOf):
    _child_spec = algos.DigestAlgorithm


class EvidenceRecord(core.Sequence):
    """RFC 4998 section 3. ``cryptoInfos`` and ``encryptionInfo`` are not supported: the
    Vault never writes them, and a record carrying them fails to parse."""

    _fields = [
        ("version", core.Integer),
        ("digest_algorithms", DigestAlgorithms),
        ("archive_time_stamp_sequence", ArchiveTimeStampSequence),
    ]


# --------------------------------------------------------------------------- #
# The hash tree
# --------------------------------------------------------------------------- #


def digest(algorithm: str, data: bytes) -> bytes:
    return HASHES[algorithm](data).digest()


def node_hash(algorithm: str, values: Iterable[bytes]) -> bytes:
    """A node's hash: its values sorted binary ascending, concatenated, hashed (RFC 4998
    4.2). A node holding ONE value is that value, not its hash: the convention of
    Bouncy Castle's independent implementation (``ERSUtil.computeNodeHash``), which the
    cross-check of 2026-10-08 showed differs from hashing the single value (plan C.24,
    design note B). Records name it in :data:`CONVENTION`."""
    values = list(values)
    if len(values) == 1:
        return values[0]
    return digest(algorithm, b"".join(sorted(values)))


def branch_hash(algorithm: str, a: bytes, b: bytes) -> bytes:
    """Two hashes combined: the smaller first, concatenated, hashed (RFC 4998 4.2)."""
    return digest(algorithm, min(a, b) + max(a, b))


def build_tree(
    algorithm: str, groups: list[list[bytes]]
) -> tuple[bytes, list[list[list[bytes]]]]:
    """The root over ``groups`` (each a list of data-object hashes) and, per group, its
    reduced hash tree: the group's own hashes, then the sibling hashes at each level.

    Nodes are paired level by level; an unpaired node moves up a level unchanged and
    contributes no list for that level.
    """
    if not groups:
        raise ValueError("a hash tree needs at least one group")
    if len({tuple(sorted(g)) for g in groups}) != len(groups):
        # Two equal leaves would make a sibling equal to the node computed beside it,
        # which RFC 4998 4.3's "becomes a member of the next list" cannot tell apart.
        raise ValueError("a hash tree's groups must be distinct")
    level = [node_hash(algorithm, group) for group in groups]
    reduced: list[list[list[bytes]]] = [[list(group)] for group in groups]
    members: list[list[int]] = [[i] for i in range(len(groups))]
    while len(level) > 1:
        next_level, next_members = [], []
        for i in range(0, len(level), 2):
            if i + 1 == len(level):
                next_level.append(level[i])
                next_members.append(members[i])
                continue
            left, right = level[i], level[i + 1]
            for g in members[i]:
                reduced[g].append([right])
            for g in members[i + 1]:
                reduced[g].append([left])
            next_level.append(node_hash(algorithm, (left, right)))
            next_members.append(members[i] + members[i + 1])
        level, members = next_level, next_members
    return level[0], reduced


def root_from_reduced(algorithm: str, reduced: list[list[bytes]]) -> bytes:
    """RFC 4998 4.3 step 3, as Bouncy Castle reads it: the first list's node hash, then,
    level by level, combined with the node hash of that level's list of siblings."""
    current = node_hash(algorithm, reduced[0])
    for siblings in reduced[1:]:
        current = branch_hash(algorithm, current, node_hash(algorithm, siblings))
    return current


def encode_record(algorithm: str, reduced: list[list[bytes]], token: bytes) -> bytes:
    """One evidence record: one chain, one archive timestamp, its reduced tree."""
    ats = _ats(algorithm, reduced, token)
    record = EvidenceRecord(
        {
            "version": 1,
            "digest_algorithms": [{"algorithm": algorithm}],
            "archive_time_stamp_sequence": [[ats]],
        }
    )
    return record.dump()


def _algorithm_of(record: "EvidenceRecord", ats: ArchiveTimeStamp) -> str:
    if ats["digest_algorithm"].native:
        return ats["digest_algorithm"]["algorithm"].native
    return record["digest_algorithms"][0]["algorithm"].native


def _ats(algorithm: str, reduced: list[list[bytes]], token: bytes) -> ArchiveTimeStamp:
    return ArchiveTimeStamp(
        {
            "digest_algorithm": {"algorithm": algorithm},
            "attributes": [
                {
                    "type": CONVENTION_OID,
                    "values": [core.UTF8String(CONVENTION)],
                }
            ],
            "reduced_hashtree": [list(level) for level in reduced],
            "time_stamp": cms.ContentInfo.load(token),
        }
    )


def convention_of(ats: ArchiveTimeStamp) -> str | None:
    """The hash-tree convention an archive timestamp names, or None if it names none
    (a record from another implementation, read under the default convention)."""
    for attribute in ats["attributes"] or []:
        if attribute["type"].dotted == CONVENTION_OID:
            return core.UTF8String.load(attribute["values"][0].dump()).native
    return None


def chain_algorithm(record_der: bytes) -> str:
    """The hash algorithm of the record's newest chain (what a timestamp renewal uses)."""
    record = EvidenceRecord.load(record_der)
    last_chain = record["archive_time_stamp_sequence"][-1]
    return _algorithm_of(record, last_chain[0])


def newest_stamp(record_der: bytes) -> dict:
    """What the newest archive timestamp says about itself, read from its token alone:
    its time, and the expiry of the certificate that signed it. For choosing what to
    renew; it is not verification (no anchor is consulted)."""
    record = EvidenceRecord.load(record_der)
    chains = record["archive_time_stamp_sequence"]
    last = chains[-1][-1]
    signed_data = last["time_stamp"]["content"]
    tst = tsp.TSTInfo.load(signed_data["encap_content_info"]["content"].contents)
    signer = _signer_certificate(signed_data, signed_data["signer_infos"][0])
    leaf = x509.load_der_x509_certificate(signer.dump())
    return {
        "gen_time": tst["gen_time"].native,
        "signer_not_after": leaf.not_valid_after_utc,
        "algorithm": _algorithm_of(record, chains[-1][0]),
        "stamps": sum(len(chain) for chain in chains),
        "chains": len(chains),
    }


def timestamp_renewal_leaf(record_der: bytes) -> bytes:
    """RFC 4998 5.2: a timestamp renewal covers the newest archive timestamp's
    ``timeStamp`` field (the DER of its ContentInfo), hashed with the chain's algorithm.
    """
    record = EvidenceRecord.load(record_der)
    last = record["archive_time_stamp_sequence"][-1][-1]
    return digest(_algorithm_of(record, last), last["time_stamp"].dump())


def hash_tree_renewal_leaves(
    record_der: bytes, algorithm: str, data_objects: list[bytes]
) -> list[bytes]:
    """RFC 4998 5.3: under the NEW algorithm, each data object's hash combined with the
    hash of the whole ArchiveTimeStampSequence so far, see :func:`renewal_leaf`."""
    record = EvidenceRecord.load(record_der)
    sequence = digest(algorithm, record["archive_time_stamp_sequence"].dump())
    return [renewal_leaf(algorithm, d, sequence) for d in data_objects]


def renewal_leaf(algorithm: str, data: bytes, sequence_hash: bytes) -> bytes:
    """RFC 4998 5.3 as written, and as Bouncy Castle implements it
    (``ERSUtil.concatPreviousHashes``): H(h(d) + ha), the data object's hash FIRST and
    the sequence hash second, NOT sorted. Until the 2026-10-08 cross-check this sorted
    the two; that agreed with Bouncy Castle only when the data hash happened to be the
    smaller (plan C.24, design note B)."""
    return digest(algorithm, digest(algorithm, data) + sequence_hash)


def append_timestamp_renewal(
    record_der: bytes, reduced: list[list[bytes]], token: bytes
) -> bytes:
    """The record with one more archive timestamp in its newest chain. Nothing already in
    the record changes: the old timestamps stay, byte for byte."""
    record = EvidenceRecord.load(record_der)
    chains = [list(chain) for chain in record["archive_time_stamp_sequence"]]
    algorithm = _algorithm_of(record, chains[-1][0])
    chains[-1].append(_ats(algorithm, reduced, token))
    return EvidenceRecord(
        {
            "version": 1,
            "digest_algorithms": list(record["digest_algorithms"]),
            "archive_time_stamp_sequence": chains,
        }
    ).dump()


def append_hash_tree_renewal(
    record_der: bytes, algorithm: str, reduced: list[list[bytes]], token: bytes
) -> bytes:
    """The record with a new chain under ``algorithm``. The old chains stay unchanged."""
    record = EvidenceRecord.load(record_der)
    chains = [list(chain) for chain in record["archive_time_stamp_sequence"]]
    chains.append([_ats(algorithm, reduced, token)])
    algorithms = [a["algorithm"].native for a in record["digest_algorithms"]]
    if algorithm not in algorithms:
        algorithms.append(algorithm)
    return EvidenceRecord(
        {
            "version": 1,
            "digest_algorithms": [{"algorithm": a} for a in algorithms],
            "archive_time_stamp_sequence": chains,
        }
    ).dump()


# --------------------------------------------------------------------------- #
# RFC 3161 token verification
# --------------------------------------------------------------------------- #


def _result(status: VerificationStatus, detail: str) -> VerificationResult:
    return VerificationResult(status, detail)


def _set_of(signed_attrs: cms.CMSAttributes) -> bytes:
    """Signed attributes are signed as a SET OF (RFC 5652 5.4), not as their [0] tag."""
    der = signed_attrs.dump()
    return b"\x31" + der[1:]


def _attr(signed_attrs: cms.CMSAttributes, name: str):
    for attribute in signed_attrs:
        if attribute["type"].native == name:
            return attribute["values"][0]
    return None


def _signer_certificate(signed_data: cms.SignedData, signer: cms.SignerInfo):
    sid = signer["sid"]
    for choice in signed_data["certificates"] or []:
        if choice.name != "certificate":
            continue
        cert = choice.chosen
        if sid.name == "issuer_and_serial_number":
            want = sid.chosen
            if (
                cert.issuer == want["issuer"]
                and cert.serial_number == want["serial_number"].native
            ):
                return cert
        elif cert.key_identifier == sid.chosen.native:
            return cert
    return None


def _verify_signature(cert_der: bytes, signer: cms.SignerInfo) -> bool:
    public_key = x509.load_der_x509_certificate(cert_der).public_key()
    digest_name = signer["digest_algorithm"]["algorithm"].native
    if digest_name not in _CRYPTO_HASHES:
        return False
    chosen = _CRYPTO_HASHES[digest_name]()
    data = _set_of(signer["signed_attrs"])
    signature = signer["signature"].native
    algo = signer["signature_algorithm"].signature_algo
    try:
        if isinstance(public_key, ec.EllipticCurvePublicKey) and algo == "ecdsa":
            public_key.verify(signature, data, ec.ECDSA(chosen))
        elif isinstance(public_key, rsa.RSAPublicKey) and algo == "rsassa_pkcs1v15":
            public_key.verify(signature, data, padding.PKCS1v15(), chosen)
        else:
            return False
    except InvalidSignature:
        return False
    return True


def _cert_binding_ok(signed_attrs: cms.CMSAttributes, cert_der: bytes) -> bool:
    v2 = _attr(signed_attrs, "signing_certificate_v2")
    if v2 is not None:
        ess = v2["certs"][0]
        name = ess["hash_algorithm"]["algorithm"].native
        return name in HASHES and ess["cert_hash"].native == digest(name, cert_der)
    v1 = _attr(signed_attrs, "signing_certificate")
    if v1 is not None:
        return v1["certs"][0]["cert_hash"].native == hashlib.sha1(cert_der).digest()
    return False


def _issuer_of(
    cert: x509.Certificate, pool: list[x509.Certificate]
) -> x509.Certificate | None:
    for candidate in pool:
        if candidate.subject != cert.issuer:
            continue
        try:
            constraints = candidate.extensions.get_extension_for_class(
                x509.BasicConstraints
            ).value
        except x509.ExtensionNotFound:
            continue
        if not constraints.ca:
            continue
        try:
            cert.verify_directly_issued_by(candidate)
        except (ValueError, TypeError, InvalidSignature):
            continue
        return candidate
    return None


def verify_token(
    token: bytes,
    algorithm: str,
    expected: bytes,
    anchors_pem: list[bytes],
    *,
    at: dt.datetime | None,
) -> tuple[VerificationResult, dict]:
    """Verify one RFC 3161 token over ``expected``. Returns the result and, when the token
    could be read, what it says (``gen_time``, the TSA's subject, ``path_not_after``: the
    earliest expiry on its certificate path). ``at=None`` skips the expiry check; the
    record verifier then applies the renewal rule itself."""
    info: dict = {}
    try:
        content_info = cms.ContentInfo.load(token)
        if content_info["content_type"].native != "signed_data":
            raise ValueError("not CMS SignedData")
        signed_data = content_info["content"]
        encap = signed_data["encap_content_info"]
        if encap["content_type"].native != "tst_info":
            raise ValueError("not an RFC 3161 TSTInfo")
        econtent = encap["content"].contents
        tst = tsp.TSTInfo.load(econtent)
        imprint = tst["message_imprint"]
        imprint_alg = imprint["hash_algorithm"]["algorithm"].native
        imprint_value = imprint["hashed_message"].native
        gen_time = tst["gen_time"].native
        signers = signed_data["signer_infos"]
    except (ValueError, TypeError, KeyError) as exc:
        return (
            _result(VerificationStatus.TIMESTAMP_INVALID, f"token unreadable: {exc}"),
            info,
        )
    info["gen_time"] = gen_time

    if imprint_alg != algorithm or imprint_value != expected:
        return (
            _result(
                VerificationStatus.EVIDENCE_MISMATCH,
                f"the token stamps a different {imprint_alg} value than the record "
                "computes from these bytes",
            ),
            info,
        )

    if len(signers) != 1 or not signers[0]["signed_attrs"]:
        return (
            _result(
                VerificationStatus.TIMESTAMP_INVALID,
                "expected one signer with signed attributes",
            ),
            info,
        )
    signer = signers[0]
    attrs = signer["signed_attrs"]
    content_type = _attr(attrs, "content_type")
    message_digest = _attr(attrs, "message_digest")
    digest_name = signer["digest_algorithm"]["algorithm"].native
    if content_type is None or content_type.native != "tst_info":
        return (
            _result(
                VerificationStatus.TIMESTAMP_INVALID,
                "content-type attribute is not TSTInfo",
            ),
            info,
        )
    if (
        message_digest is None
        or digest_name not in HASHES
        or message_digest.native != digest(digest_name, econtent)
    ):
        return (
            _result(
                VerificationStatus.TIMESTAMP_INVALID,
                "the token's message digest does not match its content (modified token)",
            ),
            info,
        )
    signer_cert = _signer_certificate(signed_data, signer)
    if signer_cert is None:
        return (
            _result(
                VerificationStatus.TIMESTAMP_INVALID,
                "the signing certificate is not in the token",
            ),
            info,
        )
    cert_der = signer_cert.dump()
    if not _verify_signature(cert_der, signer):
        return (
            _result(
                VerificationStatus.TIMESTAMP_INVALID,
                "the token's signature does not verify",
            ),
            info,
        )
    if not _cert_binding_ok(attrs, cert_der):
        return (
            _result(
                VerificationStatus.TIMESTAMP_INVALID,
                "the signing-certificate attribute does not name the signing certificate",
            ),
            info,
        )

    leaf = x509.load_der_x509_certificate(cert_der)
    info["tsa_subject"] = leaf.subject.rfc4514_string()
    info["tsa_not_after"] = leaf.not_valid_after_utc
    try:
        eku = leaf.extensions.get_extension_for_class(x509.ExtendedKeyUsage)
        timestamping = (
            eku.critical and x509.oid.ExtendedKeyUsageOID.TIME_STAMPING in eku.value
        )
    except x509.ExtensionNotFound:
        timestamping = False
    if not timestamping:
        return (
            _result(
                VerificationStatus.TSA_UNTRUSTED,
                "the signer is not a time-stamping certificate (critical EKU timeStamping)",
            ),
            info,
        )

    anchors = [x509.load_pem_x509_certificate(pem) for pem in anchors_pem]
    anchor_der = {a.public_bytes(_DER) for a in anchors}
    carried = [
        x509.load_der_x509_certificate(c.chosen.dump())
        for c in signed_data["certificates"] or []
        if c.name == "certificate"
    ]
    path, current = [leaf], leaf
    while current.public_bytes(_DER) not in anchor_der:
        issuer = _issuer_of(current, anchors + carried)
        if issuer is None or issuer in path or len(path) > 8:
            return (
                _result(
                    VerificationStatus.TSA_UNTRUSTED,
                    f"{info['tsa_subject']} does not chain to a supplied trust anchor",
                ),
                info,
            )
        path.append(issuer)
        current = issuer
    for cert in path:
        if not cert.not_valid_before_utc <= gen_time <= cert.not_valid_after_utc:
            return (
                _result(
                    VerificationStatus.TSA_UNTRUSTED,
                    f"{cert.subject.rfc4514_string()} was not valid at the token's time "
                    f"{gen_time.isoformat()}",
                ),
                info,
            )
    info["path_not_after"] = min(c.not_valid_after_utc for c in path)
    info["expiring_subject"] = min(
        path, key=lambda c: c.not_valid_after_utc
    ).subject.rfc4514_string()
    expired = [c for c in path if at is not None and at > c.not_valid_after_utc]
    if expired:
        first = min(expired, key=lambda c: c.not_valid_after_utc)
        return (
            _result(
                VerificationStatus.TSA_EXPIRED,
                f"{first.subject.rfc4514_string()} expired on "
                f"{first.not_valid_after_utc.isoformat()}, before the verification time "
                f"{at.isoformat()}; the record needed renewal before then",
            ),
            info,
        )
    return (
        _result(
            VerificationStatus.OK,
            f"timestamped {gen_time.isoformat()} by {info['tsa_subject']}",
        ),
        info,
    )


# --------------------------------------------------------------------------- #
# Evidence records
# --------------------------------------------------------------------------- #


def verify_evidence_record_bytes(
    record: bytes,
    data_objects: list[bytes],
    anchors_pem: list[bytes],
    *,
    at: dt.datetime | None = None,
) -> VerificationResult:
    """Verify an RFC 4998 evidence record over ``data_objects`` (the artefact and its
    manifest, in any order), against the TSA trust anchors given, at time ``at``
    (default: now, UTC)."""
    at = at or dt.datetime.now(dt.timezone.utc)
    if not data_objects:
        return _result(VerificationStatus.USAGE, "no data objects given")
    if not anchors_pem:
        return _result(VerificationStatus.USAGE, "no TSA trust anchor given")
    try:
        parsed = EvidenceRecord.load(record)
        version = parsed["version"].native
        chains = parsed["archive_time_stamp_sequence"]
        chain_list = [[ats for ats in chain] for chain in chains]
        _ = parsed.native  # force a full parse: a damaged record fails here, not later
    except (ValueError, TypeError) as exc:
        return _result(
            VerificationStatus.MALFORMED_INPUT,
            f"not an RFC 4998 evidence record: {exc}",
        )
    if version != 1:
        return _result(
            VerificationStatus.UNSUPPORTED_SCHEMA_VERSION,
            f"evidence record version {version}",
        )
    if not chain_list or any(not chain for chain in chain_list):
        return _result(
            VerificationStatus.MALFORMED_INPUT, "an empty archive timestamp chain"
        )

    # Walk every archive timestamp in order. Each must cover what it claims to cover:
    # the first of the first chain covers the data objects; a later one in the same
    # chain covers the previous timestamp (5.2); the first of a later chain covers the
    # data objects together with every earlier chain (5.3).
    stamps: list[dict] = []
    for k, chain in enumerate(chain_list):
        algorithm = _algorithm_of(parsed, chain[0])
        if algorithm not in HASHES:
            return _result(
                VerificationStatus.UNSUPPORTED_SCHEMA_VERSION,
                f"hash algorithm {algorithm}",
            )
        for j, ats in enumerate(chain):
            if _algorithm_of(parsed, ats) != algorithm:
                return _result(
                    VerificationStatus.MALFORMED_INPUT,
                    f"chain {k + 1} mixes hash algorithms",
                )
            convention = convention_of(ats)
            if convention is not None and convention not in KNOWN_CONVENTIONS:
                return _result(
                    VerificationStatus.UNSUPPORTED_SCHEMA_VERSION,
                    f"archive timestamp {k + 1}.{j + 1} names a hash-tree convention "
                    f"this verifier does not know: {convention!r}",
                )
            reduced = [
                [v.native for v in level] for level in ats["reduced_hashtree"] or []
            ]
            if not reduced:
                return _result(
                    VerificationStatus.MALFORMED_INPUT,
                    f"archive timestamp {k + 1}.{j + 1} carries no reduced hash tree",
                )
            if j > 0:
                needed = [digest(algorithm, chain[j - 1]["time_stamp"].dump())]
                what = f"the timestamp it renews (chain {k + 1}, link {j})"
            elif k == 0:
                needed = [digest(algorithm, d) for d in data_objects]
                what = "the data objects"
            else:
                sequence = ArchiveTimeStampSequence(
                    [list(c) for c in chain_list[:k]]
                ).dump()
                hs = digest(algorithm, sequence)
                needed = [renewal_leaf(algorithm, d, hs) for d in data_objects]
                what = "the data objects and every earlier chain"
            for index, value in enumerate(needed):
                if value not in reduced[0]:
                    return _result(
                        VerificationStatus.EVIDENCE_MISMATCH,
                        f"archive timestamp {k + 1}.{j + 1} ({algorithm}) does not cover "
                        f"{what}"
                        + (
                            f": data object {index + 1}'s bytes differ from the bytes "
                            "that were timestamped"
                            if what.startswith("the data")
                            else ": the chain is broken"
                        ),
                    )
            root = root_from_reduced(algorithm, reduced)
            result, info = verify_token(
                ats["time_stamp"].dump(), algorithm, root, anchors_pem, at=None
            )
            if not result.verified:
                return _result(
                    result.status, f"archive timestamp {k + 1}.{j + 1}: {result.detail}"
                )
            stamps.append({"label": f"{k + 1}.{j + 1}", **info})

    # The renewal rule: each timestamp must be covered by the next one while its
    # certificate path was still valid, and the newest must be valid now (at ``at``).
    for earlier, later in zip(stamps, stamps[1:]):
        if later["gen_time"] < earlier["gen_time"]:
            return _result(
                VerificationStatus.EVIDENCE_MISMATCH,
                f"archive timestamp {later['label']} is dated before the one it covers",
            )
        if later["gen_time"] > earlier["path_not_after"]:
            return _result(
                VerificationStatus.TSA_EXPIRED,
                f"archive timestamp {earlier['label']}: {earlier['expiring_subject']} "
                f"expired on {earlier['path_not_after'].isoformat()}, before the renewal "
                f"at {later['gen_time'].isoformat()} covered it; renewed too late",
            )
    newest = stamps[-1]
    if at > newest["path_not_after"]:
        return _result(
            VerificationStatus.TSA_EXPIRED,
            f"{newest['expiring_subject']} expired on "
            f"{newest['path_not_after'].isoformat()}, before the verification time "
            f"{at.isoformat()}; the record needed renewal before then",
        )
    first = stamps[0]
    renewals = len(stamps) - 1
    return _result(
        VerificationStatus.OK,
        f"unchanged since {first['gen_time'].isoformat()} (timestamped by "
        f"{first['tsa_subject']})"
        + (
            f"; renewed {renewals} time(s), newest {newest['gen_time'].isoformat()} by "
            f"{newest['tsa_subject']}"
            if renewals
            else ""
        ),
    )
